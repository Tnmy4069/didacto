
<?php
// Connecting to the Database
$servername = "localhost";
$username = "root";
$password = "";
$database = "didact";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}else{
	echo "Database connected";
}


	$password = $_POST["password"];
	$cpassword = $_POST["cpassword"];
	$fname = $_POST["fname"];
	$lname = $_POST["lname"];
	$phone = $_POST["phone"];
	$email = $_POST["email"];
	$state = $_POST["state"];
	$city = $_POST["city"];
	$pincode = $_POST["pincode"];
	$area = $_POST["area"];
	$class = $_POST["class"];
	$qualification = $_POST["qualification"];
	$board = $_POST["board"];



$sql = "INSERT INTO `teacher` (`fname`, `lname`, `phone`, `email`, `state`, `city`, `pincode`, `area`, `class`, `board`, `qualification`, `password`, `activation`) VALUES ('$fname', '$lname','$phone', '$email', '$state', '$city', '$pincode', '$area', '$class', '$board', `$qualification` '$password', '$phone')";

if ($conn->query($sql) === TRUE) {
	$user = true;
	echo "Your Registration is Successfull Completed";
	header( "Location: login.php?user=$user" );

  } else {
	echo "Error: " . $sql . "<br>" . $conn->error;
	header("Location : https://google.com");
  }

?>