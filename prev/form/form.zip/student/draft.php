<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="author" content="Kodinger">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Didactology&mdash; Student Registration</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/my-login.css">

	<script src="compo/cities.js"></script>

	<style type="text/css">
		img {
			border-width: 0
		}

		* {
			font-family: 'Lucida Grande', sans-serif;
		}
	</style>


	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<script src="js/countrystatecity.js"></script>





</head>

<?php
// Connecting to the Database
$servername = "localhost";
$username = "root";
$password = "";
$database = "didact";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}else{
	echo "Database connected";
}


	$password = $_POST["password"];
	$cpassword = $_POST["cpassword"];
	$name = $_POST["name"];
	$phone = $_POST["phone"];
	$email = $_POST["email"];
	$state = $_POST["state"];
	$city = $_POST["city"];
	$pincode = $_POST["pincode"];
	$area = $_POST["area"];
	$class = $_POST["class"];
	$board = $_POST["board"];



$sql = "INSERT INTO `students` (`name`, `phone`, `email`, `state`, `city`, `pincode`, `area`, `class`, `board`, `password`) VALUES ('$name', '$phone', '$email', '$state', '$city', '$pincode', '$area', '$class', '$board', '$password')";

if ($conn->query($sql) === TRUE) {
	$user = true;
	echo "Your Registration is Successfull Completed";
	header( "Location: login.php?user=$user" );

  } else {
	echo "Error: " . $sql . "<br>" . $conn->error;
  }

?>