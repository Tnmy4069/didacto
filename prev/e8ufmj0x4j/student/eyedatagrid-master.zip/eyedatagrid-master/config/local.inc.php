<?php
return [
    'host' => '',
    'user' => '',
    'password' => '',
    'db' => ''
]
?> 