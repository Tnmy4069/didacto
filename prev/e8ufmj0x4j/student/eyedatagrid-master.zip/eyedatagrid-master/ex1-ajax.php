<?php
require 'class.eyedatagrid.inc.php';

// Just call one function and your table is now totally Ajax enabled!
EyeDataGrid::useAjaxTable('ex1.php');